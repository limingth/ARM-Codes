
void led_init(void);

void led_on(void);

void led_off(void);