
#include "uart.h"

#if 0
void delay(void)
{
	int i;
	
	for (i = 0; i < 0x100000; i++)
		;
}
#endif


