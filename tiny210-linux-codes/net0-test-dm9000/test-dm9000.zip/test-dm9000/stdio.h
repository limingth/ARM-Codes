

int putchar(int c);

int getchar(void);

int puts(const char * s);

char * gets(char * s);

int printf(const char * format, ...);



