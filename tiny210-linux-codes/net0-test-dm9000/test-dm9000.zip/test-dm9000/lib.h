
int puts(const char * s);

void putchar_hex(char c);

int putchar(int c);
